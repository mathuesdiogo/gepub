default_app_config = "apps.educacao.apps.EducacaoConfig"

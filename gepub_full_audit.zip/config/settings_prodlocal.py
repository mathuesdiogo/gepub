from .settings import *  # importa tudo do settings atual

DEBUG = False
ALLOWED_HOSTS = ["127.0.0.1", "localhost"]

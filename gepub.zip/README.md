# GEPUB (Gestão Estratégica Pública)

Monólito modular estilo SUAP, com apps:
- core
- accounts
- pessoas
- org
- educacao
- nee

## Rodar local
```bash
source venv/bin/activate
python manage.py migrate
python manage.py runserver
python manage.py createsuperuser



## UI Core
- Layout base: `templates/core/base.html`
- Layout público (sem sidebar): `templates/core/base_public.html`
- Mensagens (success/error) aparecem automaticamente no layout.
- Templates de erro:
  - `templates/404.html`
  - `templates/500.html`

## Navegação (UI Core)
- Breadcrumbs: definido por página via `{% block breadcrumbs %}`.
- Menu ativo: baseado em `request.resolver_match.namespace`.
- Título: `base.html` usa `{% block header %}`.
## Módulo ORG
Entidades base do sistema:
- Município → Secretarias → Unidades → Setores

Regras:
- Relacionamentos usam `on_delete=PROTECT` para evitar exclusões acidentais.
- Unicidade:
  - Secretaria única por município (nome)
  - Unidade única por secretaria (nome)
  - Setor único por unidade (nome)

## ORG - CRUD (fora do admin)
Rotas iniciais:
- /org/municipios/ (lista + busca + paginação)
- /org/municipios/novo/
- /org/municipios/<id>/
- /org/municipios/<id>/editar/

git add README.md
git commit -m "docs(org): documentar campos de prefeitura no municipio"


💡 Dica importante pra evitar isso no GEPUB
Da próxima vez que for mexer em tema / layout / CSS grande:
git checkout -b tema-novo


Se quebrar:
git checkout main
Sem trauma, sem perder nada 😎
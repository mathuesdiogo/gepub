from __future__ import annotations

from django.urls import path

from .views_necessidades import AlunoNecessidadeListView
from .views_laudos import LaudoListView
from .views_recursos import RecursoListView
from .views_apoios import ApoioListView
from .views_acompanhamentos import AcompanhamentoListView
from .views_timeline import timeline_unificada
from .views_plus import aluno_hub
from .views_alertas import alertas_index, alertas_lista
from .views_dashboard import index
from .views_busca import buscar_aluno, buscar_aluno_autocomplete
from .views_relatorios import (
    relatorios_index,
    relatorios_por_tipo,
    relatorios_por_municipio,
    relatorios_por_unidade,
    relatorios_alunos,
)

# Tipos (CBVs)
from .views_tipos import TipoListView, TipoCreateView, TipoUpdateView
try:
    from .views_tipos import TipoDetailView
except Exception:  # pragma: no cover
    TipoDetailView = TipoUpdateView  # fallback compat

app_name = "nee"

urlpatterns = [
    path("", index, name="index"),

    # Tipos de Necessidade
    path("tipos/", TipoListView.as_view(), name="tipo_list"),
    path("tipos/novo/", TipoCreateView.as_view(), name="tipo_create"),
    path("tipos/<int:pk>/", TipoDetailView.as_view(), name="tipo_detail"),
    path("tipos/<int:pk>/editar/", TipoUpdateView.as_view(), name="tipo_update"),

    # Relatórios
    path("relatorios/", relatorios_index, name="relatorios_index"),
    path("relatorios/por-tipo/", relatorios_por_tipo, name="relatorios_por_tipo"),
    path("relatorios/por-municipio/", relatorios_por_municipio, name="relatorios_por_municipio"),
    path("relatorios/por-unidade/", relatorios_por_unidade, name="relatorios_por_unidade"),
    path("relatorios/alunos/", relatorios_alunos, name="relatorios_alunos"),

    # Busca / Alertas
    path("buscar/", buscar_aluno, name="buscar_aluno"),
    path("buscar/autocomplete/", buscar_aluno_autocomplete, name="buscar_aluno_autocomplete"),
    path("alertas/", alertas_index, name="alertas_index"),
    path("alertas/<slug:kind>/", alertas_lista, name="alertas_lista"),
    
    
    
     # NECESSIDADES
    path("aluno/<int:aluno_id>/necessidades/", AlunoNecessidadeListView.as_view(), name="aluno_necessidades"),

    # LAUDOS
    path("aluno/<int:aluno_id>/laudos/", LaudoListView.as_view(), name="aluno_laudos"),

    # RECURSOS
    path("aluno/<int:aluno_id>/recursos/", RecursoListView.as_view(), name="aluno_recursos"),

    # APOIOS
    path("aluno/<int:aluno_id>/apoios/", ApoioListView.as_view(), name="aluno_apoios"),

    # ACOMPANHAMENTOS
    path("aluno/<int:aluno_id>/acompanhamentos/", AcompanhamentoListView.as_view(), name="aluno_acompanhamentos"),

    # TIMELINE UNIFICADA
    path("aluno/<int:aluno_id>/timeline/", timeline_unificada, name="aluno_timeline"),
    path("aluno/<int:aluno_id>/", aluno_hub, name="aluno_hub"),
]

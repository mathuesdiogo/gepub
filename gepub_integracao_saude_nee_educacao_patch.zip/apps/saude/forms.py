from django import forms

from apps.educacao.models import Aluno
from apps.org.models import Unidade
from .models import ProfissionalSaude, AtendimentoSaude


class UnidadeSaudeForm(forms.ModelForm):
    class Meta:
        model = Unidade
        fields = ["unidade", "profissional", "aluno", "data", "tipo", "cid", "paciente_nome", "paciente_cpf", "observacoes"]


class ProfissionalSaudeForm(forms.ModelForm):
    class Meta:
        model = ProfissionalSaude
        fields = ["nome", "unidade", "cargo", "cpf", "telefone", "email", "ativo"]


class AtendimentoSaudeForm(forms.ModelForm):
    class Meta:
        model = AtendimentoSaude
        fields = ["unidade", "profissional", "data", "tipo", "paciente_nome", "paciente_cpf", "observacoes",]

    def __init__(self, *args, **kwargs):
        unidades_qs = kwargs.pop("unidades_qs", None)
        profissionais_qs = kwargs.pop("profissionais_qs", None)
        super().__init__(*args, **kwargs)

        if unidades_qs is not None and "unidade" in self.fields:
            self.fields["unidade"].queryset = unidades_qs

        if profissionais_qs is not None and "profissional" in self.fields:
            self.fields["profissional"].queryset = profissionais_qs

        if "aluno" in self.fields:
            self.fields["aluno"].queryset = Aluno.objects.all().order_by("nome")
            self.fields["aluno"].required = True

        # paciente_* vira compatibilidade; quando aluno estiver preenchido, pode ficar em branco
        if "paciente_nome" in self.fields:
            self.fields["paciente_nome"].required = False
        if "paciente_cpf" in self.fields:
            self.fields["paciente_cpf"].required = False

from __future__ import annotations

from datetime import timedelta

from django.contrib.auth.decorators import login_required
from django.db.models import Max
from django.urls import reverse
from django.shortcuts import render
from django.utils import timezone

from apps.core.rbac import scope_filter_alunos
from apps.educacao.models import Aluno

from .models import AcompanhamentoNEE, LaudoNEE


@login_required
def alertas_dashboard(request):
    hoje = timezone.localdate()

    alunos_qs = scope_filter_alunos(request.user, Aluno.objects.all())

    # Laudos vencidos
    laudos_vencidos = LaudoNEE.objects.filter(aluno__in=alunos_qs, validade__isnull=False, validade__lt=hoje).count()

    # Sem acompanhamento 30 dias
    limite = hoje - timedelta(days=30)
    ult = (
        AcompanhamentoNEE.objects.filter(aluno__in=alunos_qs)
        .values("aluno_id")
        .annotate(ultima=Max("data"))
    )
    alunos_com_ultima = {x["aluno_id"]: x["ultima"] for x in ult}
    sem_30 = 0
    for a in alunos_qs.only("id"):
        ultima = alunos_com_ultima.get(a.id)
        if (not ultima) or (ultima < limite):
            sem_30 += 1

    actions = [{"label": "Voltar", "url": reverse("nee:index"), "icon": "fa-solid fa-arrow-left", "variant": "btn--ghost"}]

    cards = [
        {"title": "Laudo vencido", "description": "Alunos com laudo expirado (validade menor que hoje).", "icon": "fa-solid fa-file-circle-xmark", "kpi": laudos_vencidos, "url": reverse("nee:alertas_laudo_vencido")},
        {"title": "Sem acompanhamento 30 dias", "description": "Alunos sem registro na timeline nos últimos 30 dias.", "icon": "fa-solid fa-clock", "kpi": sem_30, "url": reverse("nee:alertas_sem_acompanhamento_30d")},
    ]

    return render(request, "nee/alertas/dashboard_alertas.html", {"actions": actions, "cards": cards})


@login_required
def alertas_laudo_vencido(request):
    hoje = timezone.localdate()
    alunos_qs = scope_filter_alunos(request.user, Aluno.objects.all())

    laudos = (
        LaudoNEE.objects.select_related("aluno")
        .filter(aluno__in=alunos_qs, validade__isnull=False, validade__lt=hoje)
        .order_by("validade")
    )

    headers = [
        {"label": "Aluno"},
        {"label": "Validade", "width": "160px"},
        {"label": "Profissional"},
    ]
    rows = []
    for l in laudos[:500]:
        rows.append(
            {
                "cells": [
                    {"text": l.aluno.nome, "url": reverse("educacao:aluno_detail", args=[l.aluno_id])},
                    {"text": l.validade.strftime("%d/%m/%Y") if l.validade else "—"},
                    {"text": l.profissional or "—"},
                ],
                "can_edit": False,
            }
        )

    actions = [{"label": "Voltar", "url": reverse("nee:alertas_dashboard"), "icon": "fa-solid fa-arrow-left", "variant": "btn--ghost"}]
    return render(
        request,
        "nee/alertas/alunos_list.html",
        {
            "title": "Laudos vencidos",
            "subtitle": "Lista de alunos com laudo expirado.",
            "actions": actions,
            "headers": headers,
            "rows": rows,
            "empty_title": "Nenhum laudo vencido",
            "empty_text": "Tudo certo por aqui.",
        },
    )


@login_required
def alertas_sem_acompanhamento_30d(request):
    hoje = timezone.localdate()
    limite = hoje - timedelta(days=30)

    alunos_qs = scope_filter_alunos(request.user, Aluno.objects.all()).only("id", "nome", "cpf", "nis")

    ult = (
        AcompanhamentoNEE.objects.filter(aluno__in=alunos_qs)
        .values("aluno_id")
        .annotate(ultima=Max("data"))
    )
    ultima_por_aluno = {x["aluno_id"]: x["ultima"] for x in ult}

    headers = [
        {"label": "Aluno"},
        {"label": "Último evento", "width": "160px"},
    ]
    rows=[]
    for a in alunos_qs:
        ultima = ultima_por_aluno.get(a.id)
        if (not ultima) or (ultima < limite):
            rows.append({
                "cells": [
                    {"text": a.nome, "url": reverse("educacao:aluno_detail", args=[a.id])},
                    {"text": ultima.strftime("%d/%m/%Y") if ultima else "—"},
                ],
                "can_edit": False,
            })

    actions = [{"label": "Voltar", "url": reverse("nee:alertas_dashboard"), "icon": "fa-solid fa-arrow-left", "variant": "btn--ghost"}]
    return render(
        request,
        "nee/alertas/alunos_list.html",
        {
            "title": "Sem acompanhamento (30 dias)",
            "subtitle": "Alunos sem registro recente na timeline.",
            "actions": actions,
            "headers": headers,
            "rows": rows,
            "empty_title": "Nenhuma pendência",
            "empty_text": "Todos os alunos possuem acompanhamento recente.",
        },
    )
